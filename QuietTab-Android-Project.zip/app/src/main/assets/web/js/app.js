const engines=[
{name:"Google",url:"https://www.google.com/search?q=",domain:"google.com"},
{name:"Bing",url:"https://www.bing.com/search?q=",domain:"bing.com"},
{name:"Yahoo",url:"https://search.yahoo.com/search?p=",domain:"search.yahoo.com"},
{name:"DuckDuckGo",url:"https://html.duckduckgo.com/html/?q=",domain:"duckduckgo.com"},
{name:"YouTube",url:"https://www.youtube.com/results?search_query=",domain:"youtube.com"},
{name:"Wikipedia",url:"https://id.wikipedia.org/w/index.php?search=",domain:"wikipedia.org"},
{name:"Brave",url:"https://search.brave.com/search?q=",domain:"brave.com"}];

let active=localStorage.getItem("qt-engine")||"Google";
const $=id=>document.getElementById(id);
function render(){
 $("engine").textContent="Mesin pencari: "+active;
 $("engines").innerHTML=engines.map(e=>`<button class="eng ${e.name===active?"sel":""}" data-e="${e.name}"><span class="ico"><img src="https://www.google.com/s2/favicons?domain=${e.domain}&sz=64" onerror="this.style.display='none'" alt=""></span><span>${e.name}</span></button>`).join("");
 document.querySelectorAll(".eng").forEach(b=>b.onclick=()=>{active=b.dataset.e;localStorage.setItem("qt-engine",active);render()});
}
function navigate(raw){
 let q=raw.trim();if(!q)return;
 let url;
 if(/^https?:\/\//i.test(q))url=q;
 else {const e=engines.find(x=>x.name===active)||engines[0];url=e.url+encodeURIComponent(q)}
 location.href=url;
}
$("searchForm").onsubmit=e=>{e.preventDefault();navigate($("q").value)};
$("menuBtn").onclick=()=> $("menu").classList.add("open");
$("menu").onclick=e=>{if(e.target===$("menu"))$("menu").classList.remove("open")};
$("dark").checked=localStorage.getItem("qt-dark")==="1";
document.body.classList.toggle("dark",$("dark").checked);
$("dark").onchange=()=>{document.body.classList.toggle("dark",$("dark").checked);localStorage.setItem("qt-dark",$("dark").checked?"1":"0")};
$("safe").checked=localStorage.getItem("qt-safe")==="1";
$("safe").onchange=()=>{localStorage.setItem("qt-safe",$("safe").checked?"1":"0");alert("Safe Browsing tersimpan. DNS 1.1.1.1 perlu dikendalikan oleh lapisan Android/VPN; HTML tidak dapat mengubah DNS perangkat secara langsung.")};
document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>{
 const a=b.dataset.action;
 if(a==="about"){ $("menu").classList.remove("open"); $("page").classList.remove("hidden"); $("page").innerHTML=`<h2>Tentang Kami</h2><p>QuietTab adalah peramban web ringan dan fokus pada privasi.</p><p>✕ <a href="https://x.com/Quiettaboficial">X — QuietTab Oficial</a></p><p>✉ <a href="mailto:quiettaboficialacount@gmail.com?subject=Pesan%20untuk%20QuietTab">Kirim Email ke QuietTab</a></p>`}
 else {alert(a==="settings"?"Pengaturan":"Fitur "+a+" siap dikembangkan di modul native.");}
});
render();
