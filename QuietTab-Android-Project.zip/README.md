# QuietTab

Proyek Android + WebView untuk QuietTab.

## Fitur dasar
- Browser internal Android WebView, tanpa iframe.
- Mesin pencari Google, Bing, Yahoo, DuckDuckGo, YouTube, Wikipedia, Brave.
- Dark mode.
- Menu popup.
- Safe Browsing toggle dengan catatan bahwa DNS 1.1.1.1 membutuhkan kontrol native Android/VPN.
- Tentang Kami: X dan mailto Gmail.

## Build
Buka folder ini di Android Studio, lakukan Gradle Sync, lalu Build APK.

Catatan:
HTML/JavaScript biasa tidak memiliki izin untuk mengganti DNS perangkat. Untuk DNS Cloudflare 1.1.1.1 yang benar-benar memengaruhi koneksi WebView, implementasikan VpnService/Private DNS native Android pada modul DnsManager.
